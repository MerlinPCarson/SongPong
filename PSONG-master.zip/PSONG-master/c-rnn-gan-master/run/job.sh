cd /home/mogren/sync/code/mogren/c-rnn-gan/
python rnn_gan.py --model medium --datadir ~/sync/datasets/midis --traindir /home/mogren/experiments/2016-rnn-gan/20161207-large_d --feed_previous --feature_matching --bidirectional_d --learning_rate 0.1 --pretraining_epochs 6 

