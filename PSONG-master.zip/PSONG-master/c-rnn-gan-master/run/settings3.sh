#!/bin/bash

EXPERIMENT_LABEL=20161208-deep_large_d_3tpc
TRAIN_DIR=/home/mogren/experiments/2016-rnn-gan/$EXPERIMENT_LABEL
SETTINGS_LOG_DIR=$TRAIN_DIR/logs
mkdir -p $SETTINGS_LOG_DIR

