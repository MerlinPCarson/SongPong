# SongPong (RGARL-NN)

An attempt to create a musical Information-Preserving Representation-Generator for Pong using LSTMs in a Generative-Adversarial architecture to generate music that feeds a pong-playing RL Agent (Also an NN) 
